"""Package init to allow `import llmcacheproj`."""
